
  # Neomorphic Clay Design Kit (Copy)

  This is a code bundle for Neomorphic Clay Design Kit (Copy). The original project is available at https://www.figma.com/design/neK7KN1HEIvK8vXsp1KPnL/Neomorphic-Clay-Design-Kit--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  